/**
 * KRUX STUDY — Assignment Tracker
 * Add assignments with title, subject, due date; mark completed; filter pending/completed; persist in LocalStorage.
 */

import {
  STORAGE_KEYS,
  createId,
  escapeHtml,
  loadData,
  saveData,
} from './storage.js';

let assignments = loadData(STORAGE_KEYS.ASSIGNMENTS, []);
if (!Array.isArray(assignments)) {
  assignments = [];
}

let currentFilter = 'all';

function setMessage(el, text, type = 'error') {
  if (!el) return;
  if (!text) {
    el.textContent = '';
    el.className = 'form-message';
    return;
  }
  el.textContent = text;
  el.className = `form-message is-visible form-message--${type}`;
}

function getDueDescriptor(dateStr, completed) {
  if (completed) return { label: 'Completed', isOverdue: false };
  const parsed = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) return { label: dateStr, isOverdue: false };

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const diffDays = Math.round((parsed - today) / 86400000);

  if (diffDays < 0) {
    const overdue = Math.abs(diffDays);
    return {
      label: `Overdue by ${overdue} ${overdue === 1 ? 'day' : 'days'}`,
      isOverdue: true,
    };
  }
  if (diffDays === 0) return { label: 'Due today', isOverdue: false };
  if (diffDays === 1) return { label: 'Due tomorrow', isOverdue: false };
  return { label: `Due in ${diffDays} days`, isOverdue: false };
}

function formatDate(dateStr) {
  const parsed = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) return dateStr;
  return parsed.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function initAssignments() {
  const form = document.getElementById('assignment-form');
  const titleInput = document.getElementById('assign-title');
  const subjectInput = document.getElementById('assign-subject');
  const dueInput = document.getElementById('assign-due');
  const msgEl = document.getElementById('assign-message');

  const listEl = document.getElementById('assignment-list');
  const filterButtons = Array.from(document.querySelectorAll('[data-assign-filter]'));

  const metricTotal = document.getElementById('metric-assign-total');
  const metricPending = document.getElementById('metric-assign-pending');
  const metricCompleted = document.getElementById('metric-assign-completed');

  if (!form || !listEl) return;

  if (dueInput && !dueInput.value) {
    const nextWeek = new Date(Date.now() + 86400000 * 3);
    const yyyy = nextWeek.getFullYear();
    const mm = String(nextWeek.getMonth() + 1).padStart(2, '0');
    const dd = String(nextWeek.getDate()).padStart(2, '0');
    dueInput.value = `${yyyy}-${mm}-${dd}`;
  }

  function render() {
    const total = assignments.length;
    const completed = assignments.filter((a) => a.completed).length;
    const pending = total - completed;

    metricTotal.textContent = String(total);
    metricPending.textContent = String(pending);
    metricCompleted.textContent = String(completed);

    const filtered = assignments
      .filter((item) => {
        if (currentFilter === 'pending') return !item.completed;
        if (currentFilter === 'completed') return item.completed;
        return true;
      })
      .sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        return (a.dueDate || '9999-12-31').localeCompare(b.dueDate || '9999-12-31');
      });

    if (filtered.length === 0) {
      const emptyTitle =
        total === 0 ? 'No assignments tracked yet' : `No ${currentFilter} assignments`;
      const emptyText =
        total === 0
          ? 'Add an assignment title, subject, and due date to keep track of upcoming submissions.'
          : 'Switch filters above to view your other assignments.';

      listEl.innerHTML = `
        <li class="empty-state">
          <p class="empty-state-title">${emptyTitle}</p>
          <p class="empty-state-text">${emptyText}</p>
        </li>
      `;
      return;
    }

    listEl.innerHTML = filtered
      .map((item) => {
        const due = getDueDescriptor(item.dueDate, item.completed);
        return `
          <li class="list-row ${item.completed ? 'is-completed' : ''}" data-assign-id="${escapeHtml(item.id)}">
            <div class="list-row-main">
              <button
                type="button"
                class="check-btn"
                data-action="toggle"
                aria-pressed="${item.completed ? 'true' : 'false'}"
                aria-label="${item.completed ? 'Mark assignment as pending' : 'Mark assignment as completed'}"
              >
                ${
                  item.completed
                    ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'
                    : ''
                }
              </button>
              <div>
                <p class="list-row-title">${escapeHtml(item.title)}</p>
                <div class="list-row-meta">
                  <span class="meta-accent">${escapeHtml(item.subject)}</span>
                  <span aria-hidden="true">·</span>
                  <span class="tabular">Due ${escapeHtml(formatDate(item.dueDate))}</span>
                  <span aria-hidden="true">·</span>
                  <span class="${due.isOverdue ? 'meta-alert' : ''}">${escapeHtml(due.label)}</span>
                </div>
              </div>
            </div>
            <button
              type="button"
              class="icon-btn"
              data-action="delete"
              aria-label="Delete assignment ${escapeHtml(item.title)}"
            >Delete</button>
          </li>
        `;
      })
      .join('');
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const title = titleInput.value.trim();
    const subject = subjectInput.value.trim();
    const dueDate = dueInput.value;

    if (!title) {
      setMessage(msgEl, 'Please enter an assignment title.', 'error');
      titleInput.focus();
      return;
    }

    if (!subject) {
      setMessage(msgEl, 'Please enter the subject for this assignment.', 'error');
      subjectInput.focus();
      return;
    }

    if (!dueDate) {
      setMessage(msgEl, 'Please choose a due date.', 'error');
      dueInput.focus();
      return;
    }

    assignments.unshift({
      id: createId('assign'),
      title,
      subject,
      dueDate,
      completed: false,
      createdAt: Date.now(),
    });

    saveData(STORAGE_KEYS.ASSIGNMENTS, assignments);
    titleInput.value = '';
    setMessage(msgEl, 'Assignment added to your tracker.', 'success');
    render();
  });

  listEl.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-action]');
    if (!btn) return;
    const row = btn.closest('[data-assign-id]');
    if (!row) return;

    const id = row.getAttribute('data-assign-id');
    const action = btn.getAttribute('data-action');

    if (action === 'toggle') {
      assignments = assignments.map((item) =>
        item.id === id ? { ...item, completed: !item.completed } : item
      );
      saveData(STORAGE_KEYS.ASSIGNMENTS, assignments);
      render();
    } else if (action === 'delete') {
      assignments = assignments.filter((item) => item.id !== id);
      saveData(STORAGE_KEYS.ASSIGNMENTS, assignments);
      render();
    }
  });

  filterButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      currentFilter = btn.getAttribute('data-assign-filter') || 'all';
      filterButtons.forEach((b) => {
        const active = b === btn;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-pressed', String(active));
      });
      render();
    });
  });

  render();
}

document.addEventListener('DOMContentLoaded', initAssignments);
