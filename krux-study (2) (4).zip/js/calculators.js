/**
 * KRUX STUDY — Academic Calculators & Word Counter Module
 * Handles: Grade Calculator, Percentage Calculator, Attendance Calculator,
 * CGPA Calculator, and Word Counter based on document.body.dataset.tool.
 */

import { STORAGE_KEYS, loadData, saveData } from './storage.js';

function showMessage(el, text, type = 'error') {
  if (!el) return;
  if (!text) {
    el.textContent = '';
    el.className = 'form-message';
    return;
  }
  el.textContent = text;
  el.className = `form-message is-visible form-message--${type}`;
}

function parseFiniteNumber(raw) {
  if (typeof raw !== 'string') return NaN;
  const trimmed = raw.trim();
  if (trimmed === '') return NaN;
  const num = Number(trimmed);
  return Number.isFinite(num) ? num : NaN;
}

/* ==========================================================================
   1. GRADE CALCULATOR
   ========================================================================== */

const GRADE_SCALE = [
  { grade: 'A+', min: 90, gpa4: '4.0', remark: 'Outstanding' },
  { grade: 'A', min: 80, gpa4: '3.7', remark: 'Excellent' },
  { grade: 'B+', min: 75, gpa4: '3.3', remark: 'Very Good' },
  { grade: 'B', min: 70, gpa4: '3.0', remark: 'Good' },
  { grade: 'C+', min: 65, gpa4: '2.5', remark: 'Above Average' },
  { grade: 'C', min: 60, gpa4: '2.0', remark: 'Satisfactory' },
  { grade: 'D', min: 50, gpa4: '1.0', remark: 'Pass' },
  { grade: 'F', min: 0, gpa4: '0.0', remark: 'Needs Improvement' },
];

function getGradeEntry(percentage) {
  return GRADE_SCALE.find((item) => percentage >= item.min) || GRADE_SCALE[GRADE_SCALE.length - 1];
}

function initGradeCalculator() {
  const form = document.getElementById('grade-form');
  const marksInput = document.getElementById('grade-marks');
  const maxInput = document.getElementById('grade-max');
  const resetBtn = document.getElementById('grade-reset');
  const msgEl = document.getElementById('grade-message');

  const outGrade = document.getElementById('out-grade');
  const outPercent = document.getElementById('out-grade-percent');
  const outGpa = document.getElementById('out-grade-gpa');
  const outRemark = document.getElementById('out-grade-remark');
  const outBar = document.getElementById('out-grade-bar');
  const scaleRows = Array.from(document.querySelectorAll('[data-grade-row]'));

  if (!form) return;

  function clearHighlight() {
    scaleRows.forEach((row) => row.classList.remove('is-highlighted'));
  }

  function calculate() {
    const marks = parseFiniteNumber(marksInput.value);
    const max = parseFiniteNumber(maxInput.value);

    if (Number.isNaN(marks) || Number.isNaN(max)) {
      showMessage(msgEl, 'Enter both marks obtained and maximum marks.', 'error');
      return;
    }

    if (max <= 0) {
      showMessage(msgEl, 'Maximum marks must be greater than zero.', 'error');
      return;
    }

    if (marks < 0) {
      showMessage(msgEl, 'Marks obtained cannot be negative.', 'error');
      return;
    }

    if (marks > max) {
      showMessage(msgEl, 'Marks obtained cannot exceed maximum marks.', 'error');
      return;
    }

    showMessage(msgEl, '');
    const percentage = (marks / max) * 100;
    const entry = getGradeEntry(percentage);

    outGrade.textContent = entry.grade;
    outPercent.textContent = `${percentage.toFixed(2)}%`;
    outGpa.textContent = `${entry.gpa4} / 4.0`;
    outRemark.textContent = `${entry.remark} — ${marks} out of ${max} marks`;
    if (outBar) outBar.style.width = `${Math.min(100, Math.max(0, percentage))}%`;

    clearHighlight();
    const matchedRow = scaleRows.find((r) => r.getAttribute('data-grade-row') === entry.grade);
    if (matchedRow) matchedRow.classList.add('is-highlighted');
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    calculate();
  });

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      marksInput.value = '';
      maxInput.value = '100';
      showMessage(msgEl, '');
      outGrade.textContent = '—';
      outPercent.textContent = '0.00%';
      outGpa.textContent = '—';
      outRemark.textContent = 'Enter your marks to calculate your percentage and letter grade.';
      if (outBar) outBar.style.width = '0%';
      clearHighlight();
      marksInput.focus();
    });
  }
}

/* ==========================================================================
   2. PERCENTAGE CALCULATOR
   ========================================================================== */

function initPercentageCalculator() {
  const marksForm = document.getElementById('pct-marks-form');
  const changeForm = document.getElementById('pct-change-form');
  const ofForm = document.getElementById('pct-of-form');

  if (!marksForm) return;

  // Mode 1: Marks Percentage
  const mObtained = document.getElementById('pct-obtained');
  const mTotal = document.getElementById('pct-total');
  const mMsg = document.getElementById('pct-marks-message');
  const mOut = document.getElementById('pct-marks-result');
  const mDetail = document.getElementById('pct-marks-detail');

  marksForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const obtained = parseFiniteNumber(mObtained.value);
    const total = parseFiniteNumber(mTotal.value);

    if (Number.isNaN(obtained) || Number.isNaN(total)) {
      showMessage(mMsg, 'Please enter valid numbers for both fields.', 'error');
      return;
    }
    if (total <= 0) {
      showMessage(mMsg, 'Total value must be greater than zero.', 'error');
      return;
    }
    if (obtained < 0) {
      showMessage(mMsg, 'Obtained marks cannot be negative.', 'error');
      return;
    }

    showMessage(mMsg, '');
    const pct = (obtained / total) * 100;
    mOut.textContent = `${pct.toFixed(2)}%`;
    mDetail.textContent = `${obtained} out of ${total} equals ${pct.toFixed(2)}%.`;
  });

  // Mode 2: Percentage Increase / Decrease
  const cOld = document.getElementById('pct-old');
  const cNew = document.getElementById('pct-new');
  const cMsg = document.getElementById('pct-change-message');
  const cOut = document.getElementById('pct-change-result');
  const cDetail = document.getElementById('pct-change-detail');

  if (changeForm) {
    changeForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const oldVal = parseFiniteNumber(cOld.value);
      const newVal = parseFiniteNumber(cNew.value);

      if (Number.isNaN(oldVal) || Number.isNaN(newVal)) {
        showMessage(cMsg, 'Please enter valid numbers for original and new values.', 'error');
        return;
      }
      if (oldVal === 0) {
        showMessage(
          cMsg,
          'Original value cannot be zero when calculating percentage change.',
          'error'
        );
        return;
      }

      showMessage(cMsg, '');
      const diff = newVal - oldVal;
      const pctChange = (diff / Math.abs(oldVal)) * 100;
      const direction =
        diff > 0 ? 'Increase' : diff < 0 ? 'Decrease' : 'No Change';
      const sign = diff > 0 ? '+' : '';

      cOut.textContent = `${sign}${pctChange.toFixed(2)}%`;
      cDetail.textContent = `${direction} of ${Math.abs(diff).toFixed(2)} (from ${oldVal} to ${newVal}).`;
    });
  }

  // Mode 3: X% of Y
  const oRate = document.getElementById('pct-rate');
  const oBase = document.getElementById('pct-base');
  const oMsg = document.getElementById('pct-of-message');
  const oOut = document.getElementById('pct-of-result');
  const oDetail = document.getElementById('pct-of-detail');

  if (ofForm) {
    ofForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const rate = parseFiniteNumber(oRate.value);
      const base = parseFiniteNumber(oBase.value);

      if (Number.isNaN(rate) || Number.isNaN(base)) {
        showMessage(oMsg, 'Please enter valid numbers for percentage and base value.', 'error');
        return;
      }

      showMessage(oMsg, '');
      const result = (rate / 100) * base;
      oOut.textContent = Number.isInteger(result) ? String(result) : result.toFixed(2);
      oDetail.textContent = `${rate}% of ${base} is ${oOut.textContent}.`;
    });
  }
}

/* ==========================================================================
   3. ATTENDANCE CALCULATOR
   ========================================================================== */

function initAttendanceCalculator() {
  const form = document.getElementById('attendance-form');
  const totalInput = document.getElementById('att-total');
  const attendedInput = document.getElementById('att-attended');
  const targetInput = document.getElementById('att-target');
  const msgEl = document.getElementById('att-message');
  const targetPresets = Array.from(document.querySelectorAll('[data-att-target]'));

  const outPercent = document.getElementById('att-result-percent');
  const outStatus = document.getElementById('att-result-status');
  const outAction = document.getElementById('att-result-action');
  const outBar = document.getElementById('att-progress-bar');
  const metricMissed = document.getElementById('att-metric-missed');
  const metricNeeded = document.getElementById('att-metric-needed');

  if (!form) return;

  function calculate() {
    const total = parseFiniteNumber(totalInput.value);
    const attended = parseFiniteNumber(attendedInput.value);
    const target = parseFiniteNumber(targetInput.value);

    if (Number.isNaN(total) || Number.isNaN(attended) || Number.isNaN(target)) {
      showMessage(msgEl, 'Enter valid numbers for total classes, attended classes, and target percentage.', 'error');
      return;
    }

    if (!Number.isInteger(total) || !Number.isInteger(attended)) {
      showMessage(msgEl, 'Class counts must be whole numbers.', 'error');
      return;
    }

    if (total <= 0) {
      showMessage(msgEl, 'Total classes must be at least 1.', 'error');
      return;
    }

    if (attended < 0 || attended > total) {
      showMessage(msgEl, 'Attended classes must be between 0 and total classes.', 'error');
      return;
    }

    if (target <= 0 || target > 100) {
      showMessage(msgEl, 'Target percentage must be greater than 0 and at most 100.', 'error');
      return;
    }

    showMessage(msgEl, '');

    const currentPct = (attended / total) * 100;
    const missed = total - attended;
    outPercent.textContent = `${currentPct.toFixed(2)}%`;
    if (outBar) outBar.style.width = `${Math.min(100, Math.max(0, currentPct))}%`;
    metricMissed.textContent = String(missed);

    if (currentPct >= target) {
      const canMiss = Math.max(0, Math.floor((100 * attended - target * total) / target));
      outStatus.textContent =
        currentPct > target
          ? `On Track — Above your ${target}% target`
          : `On Track — Meeting your ${target}% target`;
      metricNeeded.textContent = '0';
      outAction.textContent =
        canMiss > 0
          ? `You can miss up to ${canMiss} upcoming ${canMiss === 1 ? 'class' : 'classes'} and still stay at or above ${target}%.`
          : `You are right at your ${target}% target. Attend your next class to stay on track.`;
    } else if (target === 100) {
      outStatus.textContent = 'Below Target — 100% Cannot Be Reached';
      metricNeeded.textContent = 'N/A';
      outAction.textContent =
        'Because at least one class has been missed, exact 100% attendance is no longer possible. Lower your target percentage to calculate required classes.';
    } else {
      const needed = Math.max(
        1,
        Math.ceil((target * total - 100 * attended) / (100 - target))
      );
      const projectedTotal = total + needed;
      const projectedPct = ((attended + needed) / projectedTotal) * 100;
      outStatus.textContent = `Below Target — Need ${needed} Consecutive ${needed === 1 ? 'Class' : 'Classes'}`;
      metricNeeded.textContent = String(needed);
      outAction.textContent = `Attend the next ${needed} consecutive ${needed === 1 ? 'class' : 'classes'} (${attended + needed}/${projectedTotal}) to reach ${projectedPct.toFixed(2)}%.`;
    }
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    calculate();
  });

  targetPresets.forEach((btn) => {
    btn.addEventListener('click', () => {
      targetInput.value = btn.getAttribute('data-att-target') || '75';
      if (totalInput.value && attendedInput.value) {
        calculate();
      }
    });
  });
}

/* ==========================================================================
   4. CGPA CALCULATOR
   ========================================================================== */

function initCgpaCalculator() {
  const form = document.getElementById('cgpa-form');
  const rowsContainer = document.getElementById('semester-rows');
  const addBtn = document.getElementById('add-semester-btn');
  const resetBtn = document.getElementById('reset-cgpa-btn');
  const scaleSelect = document.getElementById('cgpa-scale');
  const msgEl = document.getElementById('cgpa-message');

  const outCgpa = document.getElementById('out-cgpa');
  const outPct = document.getElementById('out-cgpa-pct');
  const outCount = document.getElementById('out-cgpa-count');
  const outHigh = document.getElementById('out-cgpa-high');
  const outDetail = document.getElementById('out-cgpa-detail');

  if (!form || !rowsContainer) return;

  const saved = loadData(STORAGE_KEYS.CGPA_DATA, {
    scale: 10,
    semesters: [
      { gpa: '', credits: '' },
      { gpa: '', credits: '' },
      { gpa: '', credits: '' },
      { gpa: '', credits: '' },
    ],
  });

  let scale = saved.scale === 4 ? 4 : 10;
  let semesters =
    Array.isArray(saved.semesters) && saved.semesters.length > 0
      ? saved.semesters
      : [
          { gpa: '', credits: '' },
          { gpa: '', credits: '' },
          { gpa: '', credits: '' },
          { gpa: '', credits: '' },
        ];

  scaleSelect.value = String(scale);

  function persist() {
    saveData(STORAGE_KEYS.CGPA_DATA, { scale, semesters });
  }

  function renderRows() {
    rowsContainer.innerHTML = semesters
      .map(
        (sem, idx) => `
        <div class="semester-row" data-sem-index="${idx}">
          <span class="semester-label">Sem ${idx + 1}</span>
          <input
            type="number"
            class="input"
            step="0.01"
            min="0"
            max="${scale}"
            placeholder="GPA (0–${scale})"
            aria-label="Semester ${idx + 1} GPA"
            data-sem-field="gpa"
            value="${sem.gpa}"
          />
          <input
            type="number"
            class="input"
            step="1"
            min="1"
            max="100"
            placeholder="Credits (opt.)"
            aria-label="Semester ${idx + 1} credits (optional)"
            data-sem-field="credits"
            value="${sem.credits}"
          />
          <button
            type="button"
            class="icon-btn"
            data-remove-sem="${idx}"
            aria-label="Remove semester ${idx + 1}"
            ${semesters.length <= 1 ? 'disabled' : ''}
          >&times;</button>
        </div>
      `
      )
      .join('');
  }

  function calculate(silent = false) {
    const validEntries = [];

    for (let i = 0; i < semesters.length; i += 1) {
      const rawGpa = String(semesters[i].gpa ?? '').trim();
      const rawCredits = String(semesters[i].credits ?? '').trim();

      if (rawGpa === '' && rawCredits === '') {
        continue;
      }

      const gpa = parseFiniteNumber(rawGpa);
      if (Number.isNaN(gpa) || gpa < 0 || gpa > scale) {
        if (!silent) {
          showMessage(
            msgEl,
            `Semester ${i + 1} GPA must be between 0 and ${scale}.`,
            'error'
          );
        }
        return;
      }

      let credits = 1;
      let hasExplicitCredits = false;
      if (rawCredits !== '') {
        credits = parseFiniteNumber(rawCredits);
        if (Number.isNaN(credits) || credits <= 0) {
          if (!silent) {
            showMessage(
              msgEl,
              `Semester ${i + 1} credits must be greater than zero.`,
              'error'
            );
          }
          return;
        }
        hasExplicitCredits = true;
      }

      validEntries.push({ gpa, credits, hasExplicitCredits });
    }

    if (validEntries.length === 0) {
      if (!silent) {
        showMessage(msgEl, 'Enter at least one semester GPA to calculate CGPA.', 'error');
      }
      outCgpa.textContent = '0.00';
      outPct.textContent = '0.0%';
      outCount.textContent = '0';
      outHigh.textContent = '—';
      outDetail.textContent = 'Enter your semester GPA values to compute your cumulative average.';
      return;
    }

    showMessage(msgEl, '');

    const useWeighted = validEntries.some((e) => e.hasExplicitCredits);
    let cgpa = 0;

    if (useWeighted) {
      const totalWeighted = validEntries.reduce((sum, e) => sum + e.gpa * e.credits, 0);
      const totalCredits = validEntries.reduce((sum, e) => sum + e.credits, 0);
      cgpa = totalWeighted / totalCredits;
    } else {
      const totalGpa = validEntries.reduce((sum, e) => sum + e.gpa, 0);
      cgpa = totalGpa / validEntries.length;
    }

    const eqPct =
      scale === 10
        ? Math.min(100, cgpa * 9.5)
        : Math.min(100, (cgpa / 4) * 100);
    const highest = Math.max(...validEntries.map((e) => e.gpa));

    outCgpa.textContent = cgpa.toFixed(2);
    outPct.textContent = `${eqPct.toFixed(1)}%`;
    outCount.textContent = String(validEntries.length);
    outHigh.textContent = highest.toFixed(2);
    outDetail.textContent = useWeighted
      ? `Credit-weighted CGPA across ${validEntries.length} ${validEntries.length === 1 ? 'semester' : 'semesters'} on a ${scale}.0 scale.`
      : `Simple average CGPA across ${validEntries.length} ${validEntries.length === 1 ? 'semester' : 'semesters'} on a ${scale}.0 scale.`;
  }

  rowsContainer.addEventListener('input', (event) => {
    const input = event.target.closest('[data-sem-field]');
    if (!input) return;
    const row = input.closest('[data-sem-index]');
    const idx = Number(row.getAttribute('data-sem-index'));
    const field = input.getAttribute('data-sem-field');
    if (semesters[idx]) {
      semesters[idx][field] = input.value;
      persist();
    }
  });

  rowsContainer.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-remove-sem]');
    if (!btn || semesters.length <= 1) return;
    const idx = Number(btn.getAttribute('data-remove-sem'));
    semesters.splice(idx, 1);
    persist();
    renderRows();
    calculate(true);
  });

  addBtn.addEventListener('click', () => {
    if (semesters.length >= 16) {
      showMessage(msgEl, 'You can track up to 16 semesters.', 'error');
      return;
    }
    semesters.push({ gpa: '', credits: '' });
    persist();
    renderRows();
  });

  scaleSelect.addEventListener('change', () => {
    scale = scaleSelect.value === '4' ? 4 : 10;
    persist();
    renderRows();
    const hasAnyValue = semesters.some(
      (s) => String(s.gpa ?? '').trim() !== '' || String(s.credits ?? '').trim() !== ''
    );
    if (hasAnyValue) {
      outCgpa.textContent = '0.00';
      outPct.textContent = '0.0%';
      outCount.textContent = '0';
      outHigh.textContent = '—';
      calculate(false);
    } else {
      calculate(true);
    }
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    calculate(false);
  });

  resetBtn.addEventListener('click', () => {
    semesters = [
      { gpa: '', credits: '' },
      { gpa: '', credits: '' },
      { gpa: '', credits: '' },
      { gpa: '', credits: '' },
    ];
    persist();
    renderRows();
    showMessage(msgEl, '');
    calculate(true);
  });

  renderRows();
  calculate(true);
}

/* ==========================================================================
   5. WORD COUNTER
   ========================================================================== */

function initWordCounter() {
  const textarea = document.getElementById('word-input');
  const outWords = document.getElementById('count-words');
  const outChars = document.getElementById('count-chars');
  const outCharsNoSpace = document.getElementById('count-chars-nospace');
  const outSentences = document.getElementById('count-sentences');
  const outParagraphs = document.getElementById('count-paragraphs');
  const outReadingTime = document.getElementById('count-reading-time');
  const copyBtn = document.getElementById('word-copy-btn');
  const clearBtn = document.getElementById('word-clear-btn');
  const statusEl = document.getElementById('word-status');

  if (!textarea || !outWords) return;

  const savedDraft = loadData(STORAGE_KEYS.WORD_DRAFT, '');
  if (typeof savedDraft === 'string' && savedDraft.length > 0) {
    textarea.value = savedDraft;
  }

  function updateCounts() {
    const text = textarea.value;
    const trimmed = text.trim();

    const words = trimmed ? trimmed.split(/\s+/).filter(Boolean).length : 0;
    const chars = text.length;
    const charsNoSpace = text.replace(/\s/g, '').length;
    const sentences = trimmed
      ? trimmed.split(/[.!?]+(?=\s|$)/).filter((s) => s.trim().length > 0).length
      : 0;
    const paragraphs = trimmed
      ? trimmed.split(/\n\s*\n/).filter((p) => p.trim().length > 0).length
      : 0;

    const readMinutes = words === 0 ? 0 : Math.max(1, Math.ceil(words / 200));

    outWords.textContent = String(words);
    outChars.textContent = String(chars);
    outCharsNoSpace.textContent = String(charsNoSpace);
    outSentences.textContent = String(sentences);
    if (outParagraphs) outParagraphs.textContent = String(paragraphs);
    if (outReadingTime) outReadingTime.textContent = words === 0 ? '0 min' : `${readMinutes} min`;

    saveData(STORAGE_KEYS.WORD_DRAFT, text);
  }

  textarea.addEventListener('input', updateCounts);

  if (copyBtn) {
    copyBtn.addEventListener('click', async () => {
      if (!textarea.value.trim()) {
        showMessage(statusEl, 'Nothing to copy yet. Type or paste text first.', 'error');
        return;
      }
      try {
        await navigator.clipboard.writeText(textarea.value);
        showMessage(statusEl, 'Text copied to clipboard.', 'success');
      } catch {
        textarea.select();
        showMessage(statusEl, 'Text selected. Press Ctrl+C or Cmd+C to copy.', 'success');
      }
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      textarea.value = '';
      updateCounts();
      showMessage(statusEl, 'Editor cleared.', 'success');
      textarea.focus();
    });
  }

  updateCounts();
}

/* ==========================================================================
   INITIALIZER DISPATCH
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  const tool = document.body.dataset.tool;
  if (tool === 'grade') initGradeCalculator();
  if (tool === 'percentage') initPercentageCalculator();
  if (tool === 'attendance') initAttendanceCalculator();
  if (tool === 'cgpa') initCgpaCalculator();
  if (tool === 'word-counter') initWordCounter();
});
