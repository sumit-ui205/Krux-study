/**
 * KRUX STUDY — Exam Countdown
 * Track multiple exams with live remaining days & hours, persisted in LocalStorage.
 */

import {
  STORAGE_KEYS,
  createId,
  escapeHtml,
  loadData,
  saveData,
} from './storage.js';

let exams = loadData(STORAGE_KEYS.COUNTDOWN_EXAMS, []);
if (!Array.isArray(exams)) {
  exams = [];
}

function setMessage(el, text, type = 'error') {
  if (!el) return;
  if (!text) {
    el.textContent = '';
    el.className = 'form-message';
    return;
  }
  el.textContent = text;
  el.className = `form-message is-visible form-message--${type}`;
}

function getExamStatus(exam) {
  const timePart = exam.time && /^\d{2}:\d{2}$/.test(exam.time) ? exam.time : '09:00';
  const target = new Date(`${exam.date}T${timePart}:00`);
  const now = new Date();

  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const examMidnight = new Date(target.getFullYear(), target.getMonth(), target.getDate());
  const calendarDays = Math.round((examMidnight - todayMidnight) / 86400000);
  const diffMs = target.getTime() - now.getTime();

  if (diffMs <= 0 && calendarDays < 0) {
    const passed = Math.abs(calendarDays);
    return {
      isPast: true,
      calendarDays,
      primaryLabel: 'Completed',
      subLabel: `${passed} ${passed === 1 ? 'day' : 'days'} ago`,
      sortOrder: 1,
      sortTime: target.getTime(),
    };
  }

  if (calendarDays === 0) {
    if (diffMs <= 0) {
      return {
        isPast: false,
        calendarDays: 0,
        primaryLabel: 'Today',
        subLabel: 'Exam time reached',
        sortOrder: 0,
        sortTime: target.getTime(),
      };
    }
    const hrs = Math.floor(diffMs / 3600000);
    const mins = Math.floor((diffMs % 3600000) / 60000);
    return {
      isPast: false,
      calendarDays: 0,
      primaryLabel: 'Today',
      subLabel: `${hrs}h ${mins}m remaining`,
      sortOrder: 0,
      sortTime: target.getTime(),
    };
  }

  const totalHours = Math.max(0, Math.floor(diffMs / 3600000));
  const remDays = Math.floor(totalHours / 24);
  const remHours = totalHours % 24;

  return {
    isPast: false,
    calendarDays,
    primaryLabel: calendarDays === 1 ? '1 day' : `${calendarDays} days`,
    subLabel: `${remDays}d ${remHours}h until start`,
    sortOrder: 0,
    sortTime: target.getTime(),
  };
}

function formatReadableDate(dateStr, timeStr) {
  const parsed = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(parsed.getTime())) return dateStr;
  const datePart = parsed.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  return timeStr ? `${datePart} · ${timeStr}` : datePart;
}

function initCountdown() {
  const form = document.getElementById('exam-form');
  const nameInput = document.getElementById('exam-name');
  const dateInput = document.getElementById('exam-date');
  const timeInput = document.getElementById('exam-time');
  const noteInput = document.getElementById('exam-note');
  const msgEl = document.getElementById('exam-message');

  const listEl = document.getElementById('exam-list');
  const metricTotal = document.getElementById('metric-exams-total');
  const metricUpcoming = document.getElementById('metric-exams-upcoming');
  const metricNext = document.getElementById('metric-exams-next');

  if (!form || !listEl) return;

  // Suggest tomorrow as default exam date
  if (dateInput && !dateInput.value) {
    const tomorrow = new Date(Date.now() + 86400000 * 7);
    const yyyy = tomorrow.getFullYear();
    const mm = String(tomorrow.getMonth() + 1).padStart(2, '0');
    const dd = String(tomorrow.getDate()).padStart(2, '0');
    dateInput.value = `${yyyy}-${mm}-${dd}`;
  }

  function render() {
    const enriched = exams
      .map((exam) => ({ exam, status: getExamStatus(exam) }))
      .sort((a, b) => {
        if (a.status.sortOrder !== b.status.sortOrder) {
          return a.status.sortOrder - b.status.sortOrder;
        }
        return a.status.sortTime - b.status.sortTime;
      });

    const upcoming = enriched.filter((item) => !item.status.isPast);
    metricTotal.textContent = String(exams.length);
    metricUpcoming.textContent = String(upcoming.length);
    metricNext.textContent =
      upcoming.length > 0 ? upcoming[0].status.primaryLabel : '—';

    if (enriched.length === 0) {
      listEl.innerHTML = `
        <div class="empty-state">
          <p class="empty-state-title">No exams added yet</p>
          <p class="empty-state-text">Enter an exam name and date to begin tracking your remaining preparation days.</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = `
      <div class="countdown-list">
        ${enriched
          .map(({ exam, status }) => {
            return `
              <article class="countdown-card" data-exam-id="${escapeHtml(exam.id)}">
                <div>
                  <div class="panel-header mb-xs">
                    <h3 class="panel-title">${escapeHtml(exam.name)}</h3>
                    <button
                      type="button"
                      class="icon-btn"
                      data-delete-exam="${escapeHtml(exam.id)}"
                      aria-label="Delete exam ${escapeHtml(exam.name)}"
                    >Delete</button>
                  </div>
                  <div class="list-row-meta">
                    <span class="tabular">${escapeHtml(formatReadableDate(exam.date, exam.time))}</span>
                    ${
                      exam.note
                        ? `<span aria-hidden="true">·</span><span>${escapeHtml(exam.note)}</span>`
                        : ''
                    }
                  </div>
                </div>
                <div>
                  <div class="countdown-days">${escapeHtml(status.primaryLabel)}</div>
                  <div class="countdown-sub">${escapeHtml(status.subLabel)}</div>
                </div>
              </article>
            `;
          })
          .join('')}
      </div>
    `;
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const name = nameInput.value.trim();
    const date = dateInput.value;
    const time = timeInput.value || '09:00';
    const note = noteInput.value.trim();

    if (!name) {
      setMessage(msgEl, 'Please enter the exam name.', 'error');
      nameInput.focus();
      return;
    }

    if (!date) {
      setMessage(msgEl, 'Please choose the exam date.', 'error');
      dateInput.focus();
      return;
    }

    const parsed = new Date(`${date}T${time}:00`);
    if (Number.isNaN(parsed.getTime())) {
      setMessage(msgEl, 'Please enter a valid date and time.', 'error');
      return;
    }

    exams.push({
      id: createId('exam'),
      name,
      date,
      time,
      note,
    });

    saveData(STORAGE_KEYS.COUNTDOWN_EXAMS, exams);
    nameInput.value = '';
    noteInput.value = '';
    setMessage(msgEl, `Added "${name}" to your countdown list.`, 'success');
    render();
  });

  listEl.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-delete-exam]');
    if (!btn) return;
    const id = btn.getAttribute('data-delete-exam');
    exams = exams.filter((e) => e.id !== id);
    saveData(STORAGE_KEYS.COUNTDOWN_EXAMS, exams);
    render();
  });

  window.setInterval(render, 30000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) render();
  });

  render();
}

document.addEventListener('DOMContentLoaded', initCountdown);
