/**
 * KRUX STUDY — Notes Organizer
 * Create, edit, delete, and live-search study notes persisted in LocalStorage.
 */

import {
  STORAGE_KEYS,
  createId,
  escapeHtml,
  loadData,
  saveData,
} from './storage.js';

let notes = loadData(STORAGE_KEYS.NOTES, []);
if (!Array.isArray(notes)) {
  notes = [];
}

let activeNoteId = null;
let searchQuery = '';
let pendingDeleteId = null;

function setMessage(el, text, type = 'success') {
  if (!el) return;
  if (!text) {
    el.textContent = '';
    el.className = 'form-message';
    return;
  }
  el.textContent = text;
  el.className = `form-message is-visible form-message--${type}`;
}

function formatUpdated(timestamp) {
  const date = new Date(timestamp);
  if (Number.isNaN(date.getTime())) return '';
  return date.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function initNotes() {
  const searchInput = document.getElementById('note-search');
  const newBtn = document.getElementById('new-note-btn');
  const noteList = document.getElementById('note-list');
  const noteCountEl = document.getElementById('note-count');

  const form = document.getElementById('note-editor-form');
  const titleInput = document.getElementById('note-title');
  const subjectInput = document.getElementById('note-subject');
  const bodyInput = document.getElementById('note-body');
  const saveBtn = document.getElementById('save-note-btn');
  const deleteBtn = document.getElementById('delete-note-btn');
  const editorHeading = document.getElementById('editor-heading');
  const editorMeta = document.getElementById('editor-meta');
  const msgEl = document.getElementById('note-message');

  if (!form || !noteList) return;

  function updateEditorMeta() {
    const text = bodyInput.value.trim();
    const words = text ? text.split(/\s+/).filter(Boolean).length : 0;
    const active = notes.find((n) => n.id === activeNoteId);
    const updatedPart = active ? `Updated ${formatUpdated(active.updatedAt)} · ` : '';
    editorMeta.textContent = `${updatedPart}${words} ${words === 1 ? 'word' : 'words'}`;
  }

  function resetEditorForNew() {
    activeNoteId = null;
    pendingDeleteId = null;
    titleInput.value = '';
    subjectInput.value = '';
    bodyInput.value = '';
    editorHeading.textContent = 'Create New Note';
    saveBtn.textContent = 'Save Note';
    deleteBtn.hidden = true;
    deleteBtn.textContent = 'Delete Note';
    setMessage(msgEl, '');
    updateEditorMeta();
    renderList();
    titleInput.focus();
  }

  function loadNoteIntoEditor(id) {
    const note = notes.find((n) => n.id === id);
    if (!note) return;
    activeNoteId = note.id;
    pendingDeleteId = null;
    titleInput.value = note.title;
    subjectInput.value = note.subject || '';
    bodyInput.value = note.body;
    editorHeading.textContent = 'Edit Note';
    saveBtn.textContent = 'Update Note';
    deleteBtn.hidden = false;
    deleteBtn.textContent = 'Delete Note';
    setMessage(msgEl, '');
    updateEditorMeta();
    renderList();
  }

  function renderList() {
    const q = searchQuery.trim().toLowerCase();
    const filtered = notes
      .filter((note) => {
        if (!q) return true;
        return (
          note.title.toLowerCase().includes(q) ||
          (note.subject || '').toLowerCase().includes(q) ||
          note.body.toLowerCase().includes(q)
        );
      })
      .sort((a, b) => b.updatedAt - a.updatedAt);

    noteCountEl.textContent = `${filtered.length} of ${notes.length} ${notes.length === 1 ? 'note' : 'notes'}`;

    if (filtered.length === 0) {
      const title = notes.length === 0 ? 'No saved notes yet' : 'No matching notes';
      const desc =
        notes.length === 0
          ? 'Write your first note in the editor to save it to your browser.'
          : 'Try a different keyword in the search box.';
      noteList.innerHTML = `
        <div class="empty-state">
          <p class="empty-state-title">${title}</p>
          <p class="empty-state-text">${desc}</p>
        </div>
      `;
      return;
    }

    noteList.innerHTML = filtered
      .map((note) => {
        const preview = note.body.replace(/\s+/g, ' ').trim() || 'Empty note body';
        const isSelected = note.id === activeNoteId;
        return `
          <button
            type="button"
            class="note-item ${isSelected ? 'is-selected' : ''}"
            data-select-note="${escapeHtml(note.id)}"
            aria-current="${isSelected ? 'true' : 'false'}"
          >
            <span class="note-item-title">${escapeHtml(note.title)}</span>
            <span class="note-item-preview">${escapeHtml(preview)}</span>
            <span class="note-item-meta">
              ${note.subject ? `<span class="meta-accent">${escapeHtml(note.subject)}</span><span aria-hidden="true">·</span>` : ''}
              <span class="tabular">${escapeHtml(formatUpdated(note.updatedAt))}</span>
            </span>
          </button>
        `;
      })
      .join('');
  }

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const title = titleInput.value.trim();
    const subject = subjectInput.value.trim();
    const body = bodyInput.value.trim();

    if (!title) {
      setMessage(msgEl, 'Please enter a title for your note.', 'error');
      titleInput.focus();
      return;
    }

    if (!body) {
      setMessage(msgEl, 'Please enter some content for your note.', 'error');
      bodyInput.focus();
      return;
    }

    const now = Date.now();
    pendingDeleteId = null;
    deleteBtn.textContent = 'Delete Note';

    if (activeNoteId) {
      notes = notes.map((n) =>
        n.id === activeNoteId
          ? { ...n, title, subject, body, updatedAt: now }
          : n
      );
      saveData(STORAGE_KEYS.NOTES, notes);
      setMessage(msgEl, 'Note updated and saved locally.', 'success');
    } else {
      const created = {
        id: createId('note'),
        title,
        subject,
        body,
        createdAt: now,
        updatedAt: now,
      };
      notes.unshift(created);
      activeNoteId = created.id;
      saveData(STORAGE_KEYS.NOTES, notes);
      editorHeading.textContent = 'Edit Note';
      saveBtn.textContent = 'Update Note';
      deleteBtn.hidden = false;
      setMessage(msgEl, 'New note created and saved locally.', 'success');
    }

    updateEditorMeta();
    renderList();
  });

  deleteBtn.addEventListener('click', () => {
    if (!activeNoteId) return;
    if (pendingDeleteId !== activeNoteId) {
      pendingDeleteId = activeNoteId;
      deleteBtn.textContent = 'Confirm Delete';
      setMessage(msgEl, 'Click "Confirm Delete" again to permanently remove this note.', 'error');
      return;
    }

    notes = notes.filter((n) => n.id !== activeNoteId);
    saveData(STORAGE_KEYS.NOTES, notes);
    pendingDeleteId = null;
    activeNoteId = null;
    titleInput.value = '';
    subjectInput.value = '';
    bodyInput.value = '';
    editorHeading.textContent = 'Create New Note';
    saveBtn.textContent = 'Save Note';
    deleteBtn.hidden = true;
    deleteBtn.textContent = 'Delete Note';
    setMessage(msgEl, 'Note deleted.', 'success');
    updateEditorMeta();
    renderList();
  });

  noteList.addEventListener('click', (event) => {
    const item = event.target.closest('[data-select-note]');
    if (!item) return;
    loadNoteIntoEditor(item.getAttribute('data-select-note'));
  });

  newBtn.addEventListener('click', resetEditorForNew);

  searchInput.addEventListener('input', () => {
    searchQuery = searchInput.value;
    renderList();
  });

  bodyInput.addEventListener('input', updateEditorMeta);

  // Auto-open most recent note if one exists
  if (notes.length > 0) {
    const latest = [...notes].sort((a, b) => b.updatedAt - a.updatedAt)[0];
    loadNoteIntoEditor(latest.id);
  } else {
    updateEditorMeta();
    renderList();
  }
}

document.addEventListener('DOMContentLoaded', initNotes);
