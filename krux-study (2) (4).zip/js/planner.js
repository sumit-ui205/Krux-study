/**
 * KRUX STUDY — Study Planner
 * Manage subjects, schedule study tasks with dates & times, toggle completion, persist in LocalStorage.
 */

import {
  STORAGE_KEYS,
  createId,
  escapeHtml,
  loadData,
  saveData,
} from './storage.js';

const DEFAULT_SUBJECTS = ['Mathematics', 'Physics', 'Computer Science', 'History'];

let subjects = loadData(STORAGE_KEYS.PLANNER_SUBJECTS, DEFAULT_SUBJECTS);
let tasks = loadData(STORAGE_KEYS.PLANNER_TASKS, []);
let statusFilter = 'all';
let subjectFilter = 'all';

if (!Array.isArray(subjects) || subjects.length === 0) {
  subjects = [...DEFAULT_SUBJECTS];
}
if (!Array.isArray(tasks)) {
  tasks = [];
}

function setMessage(el, text, type = 'error') {
  if (!el) return;
  if (!text) {
    el.textContent = '';
    el.className = 'form-message';
    return;
  }
  el.textContent = text;
  el.className = `form-message is-visible form-message--${type}`;
}

function formatDateTime(dateStr, timeStr) {
  if (!dateStr && !timeStr) return 'No schedule set';
  const parts = [];
  if (dateStr) {
    const parsed = new Date(`${dateStr}T00:00:00`);
    if (!Number.isNaN(parsed.getTime())) {
      parts.push(
        parsed.toLocaleDateString(undefined, {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        })
      );
    }
  }
  if (timeStr) {
    const [hoursStr, minutesStr] = timeStr.split(':');
    const hours = Number(hoursStr);
    const minutes = Number(minutesStr);
    if (!Number.isNaN(hours) && !Number.isNaN(minutes)) {
      const period = hours >= 12 ? 'PM' : 'AM';
      const hour12 = hours % 12 || 12;
      parts.push(`${hour12}:${String(minutes).padStart(2, '0')} ${period}`);
    }
  }
  return parts.join(' · ');
}

function initPlanner() {
  const subjectForm = document.getElementById('subject-form');
  const subjectInput = document.getElementById('subject-name');
  const subjectMsg = document.getElementById('subject-message');
  const subjectStrip = document.getElementById('subject-strip');
  const taskSubjectSelect = document.getElementById('task-subject');
  const filterSubjectSelect = document.getElementById('filter-subject');

  const taskForm = document.getElementById('task-form');
  const taskTitleInput = document.getElementById('task-title');
  const taskDateInput = document.getElementById('task-date');
  const taskTimeInput = document.getElementById('task-time');
  const taskMsg = document.getElementById('task-message');

  const taskList = document.getElementById('task-list');
  const statusButtons = Array.from(document.querySelectorAll('[data-task-filter]'));

  const metricTotal = document.getElementById('metric-total');
  const metricPending = document.getElementById('metric-pending');
  const metricCompleted = document.getElementById('metric-completed');
  const metricSubjects = document.getElementById('metric-subjects');

  if (!taskForm || !taskList) return;

  // Set default date input to today
  if (taskDateInput && !taskDateInput.value) {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    taskDateInput.value = `${yyyy}-${mm}-${dd}`;
  }

  function renderSubjects() {
    const currentTaskVal = taskSubjectSelect.value;
    const currentFilterVal = filterSubjectSelect.value;

    taskSubjectSelect.innerHTML = subjects
      .map((sub) => `<option value="${escapeHtml(sub)}">${escapeHtml(sub)}</option>`)
      .join('');

    if (subjects.includes(currentTaskVal)) {
      taskSubjectSelect.value = currentTaskVal;
    }

    filterSubjectSelect.innerHTML =
      '<option value="all">All Subjects</option>' +
      subjects
        .map((sub) => `<option value="${escapeHtml(sub)}">${escapeHtml(sub)}</option>`)
        .join('');

    filterSubjectSelect.value = subjects.includes(currentFilterVal) ? currentFilterVal : 'all';
    subjectFilter = filterSubjectSelect.value;

    subjectStrip.innerHTML = subjects
      .map(
        (sub) => `
        <span class="subject-item">
          <span>${escapeHtml(sub)}</span>
          <button
            type="button"
            class="subject-remove"
            data-remove-subject="${escapeHtml(sub)}"
            aria-label="Remove subject ${escapeHtml(sub)}"
            title="Remove subject"
          >&times;</button>
        </span>
      `
      )
      .join('');
  }

  function renderMetrics() {
    const total = tasks.length;
    const completed = tasks.filter((t) => t.completed).length;
    const pending = total - completed;

    metricTotal.textContent = String(total);
    metricPending.textContent = String(pending);
    metricCompleted.textContent = String(completed);
    metricSubjects.textContent = String(subjects.length);
  }

  function renderTasks() {
    renderMetrics();

    const filtered = tasks
      .filter((task) => {
        if (statusFilter === 'pending' && task.completed) return false;
        if (statusFilter === 'completed' && !task.completed) return false;
        if (subjectFilter !== 'all' && task.subject !== subjectFilter) return false;
        return true;
      })
      .sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        const aKey = `${a.date || '9999-12-31'} ${a.time || '23:59'}`;
        const bKey = `${b.date || '9999-12-31'} ${b.time || '23:59'}`;
        return aKey.localeCompare(bKey);
      });

    if (filtered.length === 0) {
      const emptyTitle = tasks.length === 0 ? 'No study tasks scheduled' : 'No matching tasks';
      const emptyText =
        tasks.length === 0
          ? 'Add your first study task on the left to build your daily schedule.'
          : 'Try switching the status or subject filter to view your other tasks.';
      taskList.innerHTML = `
        <li class="empty-state">
          <p class="empty-state-title">${emptyTitle}</p>
          <p class="empty-state-text">${emptyText}</p>
        </li>
      `;
      return;
    }

    taskList.innerHTML = filtered
      .map(
        (task) => `
        <li class="list-row ${task.completed ? 'is-completed' : ''}" data-task-id="${escapeHtml(task.id)}">
          <div class="list-row-main">
            <button
              type="button"
              class="check-btn"
              data-action="toggle"
              aria-pressed="${task.completed ? 'true' : 'false'}"
              aria-label="${task.completed ? 'Mark task as pending' : 'Mark task as completed'}"
            >
              ${
                task.completed
                  ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>'
                  : ''
              }
            </button>
            <div>
              <p class="list-row-title">${escapeHtml(task.title)}</p>
              <div class="list-row-meta">
                <span class="meta-accent">${escapeHtml(task.subject)}</span>
                <span aria-hidden="true">·</span>
                <span class="tabular">${escapeHtml(formatDateTime(task.date, task.time))}</span>
                <span aria-hidden="true">·</span>
                <span>${task.completed ? 'Completed' : 'Pending'}</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            class="icon-btn"
            data-action="delete"
            aria-label="Delete task ${escapeHtml(task.title)}"
          >Delete</button>
        </li>
      `
      )
      .join('');
  }

  subjectForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const name = subjectInput.value.trim();

    if (!name) {
      setMessage(subjectMsg, 'Please enter a subject name.', 'error');
      subjectInput.focus();
      return;
    }

    if (name.length > 40) {
      setMessage(subjectMsg, 'Subject name must be 40 characters or fewer.', 'error');
      return;
    }

    const exists = subjects.some((s) => s.toLowerCase() === name.toLowerCase());
    if (exists) {
      setMessage(subjectMsg, 'That subject is already in your list.', 'error');
      return;
    }

    subjects.push(name);
    saveData(STORAGE_KEYS.PLANNER_SUBJECTS, subjects);
    subjectInput.value = '';
    setMessage(subjectMsg, `Added "${name}" to your subjects.`, 'success');
    renderSubjects();
    taskSubjectSelect.value = name;
    renderMetrics();
  });

  subjectStrip.addEventListener('click', (event) => {
    const btn = event.target.closest('[data-remove-subject]');
    if (!btn) return;
    if (subjects.length <= 1) {
      setMessage(subjectMsg, 'Keep at least one subject in your planner.', 'error');
      return;
    }
    const target = btn.getAttribute('data-remove-subject');
    subjects = subjects.filter((s) => s !== target);
    saveData(STORAGE_KEYS.PLANNER_SUBJECTS, subjects);
    setMessage(subjectMsg, `Removed "${target}".`, 'success');
    renderSubjects();
    renderTasks();
  });

  taskForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const title = taskTitleInput.value.trim();
    const subject = taskSubjectSelect.value;
    const date = taskDateInput.value;
    const time = taskTimeInput.value;

    if (!title) {
      setMessage(taskMsg, 'Please enter a study task title.', 'error');
      taskTitleInput.focus();
      return;
    }

    if (!subject) {
      setMessage(taskMsg, 'Please add or choose a subject first.', 'error');
      return;
    }

    if (!date) {
      setMessage(taskMsg, 'Please select a date for this study task.', 'error');
      taskDateInput.focus();
      return;
    }

    tasks.unshift({
      id: createId('task'),
      title,
      subject,
      date,
      time,
      completed: false,
      createdAt: Date.now(),
    });

    saveData(STORAGE_KEYS.PLANNER_TASKS, tasks);
    taskTitleInput.value = '';
    setMessage(taskMsg, 'Study task added to your schedule.', 'success');
    renderTasks();
  });

  taskList.addEventListener('click', (event) => {
    const actionBtn = event.target.closest('[data-action]');
    if (!actionBtn) return;
    const row = actionBtn.closest('[data-task-id]');
    if (!row) return;

    const id = row.getAttribute('data-task-id');
    const action = actionBtn.getAttribute('data-action');

    if (action === 'toggle') {
      tasks = tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t));
      saveData(STORAGE_KEYS.PLANNER_TASKS, tasks);
      renderTasks();
    } else if (action === 'delete') {
      tasks = tasks.filter((t) => t.id !== id);
      saveData(STORAGE_KEYS.PLANNER_TASKS, tasks);
      renderTasks();
    }
  });

  statusButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      statusFilter = btn.getAttribute('data-task-filter') || 'all';
      statusButtons.forEach((b) => {
        const active = b === btn;
        b.classList.toggle('is-active', active);
        b.setAttribute('aria-pressed', String(active));
      });
      renderTasks();
    });
  });

  filterSubjectSelect.addEventListener('change', () => {
    subjectFilter = filterSubjectSelect.value;
    renderTasks();
  });

  renderSubjects();
  renderTasks();
}

document.addEventListener('DOMContentLoaded', initPlanner);
