/**
 * KRUX STUDY — Safe LocalStorage Layer
 * Handles serialization, private browsing restrictions, and quota errors gracefully.
 */

const PREFIX = 'krux_study_';
const memoryFallback = new Map();

export const STORAGE_KEYS = {
  PLANNER_SUBJECTS: 'planner_subjects',
  PLANNER_TASKS: 'planner_tasks',
  TIMER_STATE: 'timer_state',
  COUNTDOWN_EXAMS: 'countdown_exams',
  CGPA_DATA: 'cgpa_data',
  ASSIGNMENTS: 'assignments',
  WORD_DRAFT: 'word_draft',
  NOTES: 'notes',
};

function isStorageAvailable() {
  try {
    const testKey = `${PREFIX}__test__`;
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}

const storageReady = isStorageAvailable();

export function loadData(key, defaultValue) {
  const fullKey = `${PREFIX}${key}`;
  try {
    const raw = storageReady
      ? window.localStorage.getItem(fullKey)
      : memoryFallback.get(fullKey);

    if (raw === null || raw === undefined) {
      return defaultValue;
    }
    const parsed = JSON.parse(raw);
    return parsed === null || parsed === undefined ? defaultValue : parsed;
  } catch {
    return defaultValue;
  }
}

export function saveData(key, value) {
  const fullKey = `${PREFIX}${key}`;
  try {
    const serialized = JSON.stringify(value);
    if (storageReady) {
      window.localStorage.setItem(fullKey, serialized);
    } else {
      memoryFallback.set(fullKey, serialized);
    }
    return true;
  } catch {
    return false;
  }
}

export function removeData(key) {
  const fullKey = `${PREFIX}${key}`;
  try {
    if (storageReady) {
      window.localStorage.removeItem(fullKey);
    }
    memoryFallback.delete(fullKey);
    return true;
  } catch {
    return false;
  }
}

export function clearAllStudyData() {
  try {
    if (storageReady) {
      Object.values(STORAGE_KEYS).forEach((key) => {
        window.localStorage.removeItem(`${PREFIX}${key}`);
      });
    }
    memoryFallback.clear();
    return true;
  } catch {
    return false;
  }
}

export function getStorageSummary() {
  const tasks = loadData(STORAGE_KEYS.PLANNER_TASKS, []);
  const exams = loadData(STORAGE_KEYS.COUNTDOWN_EXAMS, []);
  const assignments = loadData(STORAGE_KEYS.ASSIGNMENTS, []);
  const notes = loadData(STORAGE_KEYS.NOTES, []);

  return {
    tasks: Array.isArray(tasks) ? tasks.length : 0,
    exams: Array.isArray(exams) ? exams.length : 0,
    assignments: Array.isArray(assignments) ? assignments.length : 0,
    notes: Array.isArray(notes) ? notes.length : 0,
  };
}

export function createId(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

export function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
