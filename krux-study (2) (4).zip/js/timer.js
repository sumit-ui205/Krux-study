/**
 * KRUX STUDY — Focus Timer
 * Drift-free timestamp-based countdown supporting custom study/break durations,
 * page visibility changes, session tracking, and optional completion chime.
 */

import { STORAGE_KEYS, loadData, saveData } from './storage.js';

const DEFAULT_STATE = {
  focusMinutes: 25,
  breakMinutes: 5,
  completedSessions: 0,
  totalFocusMinutes: 0,
  soundEnabled: true,
};

function playCompletionTone() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    [523.25, 659.25].forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.16);
      gain.gain.setValueAtTime(0.001, now + idx * 0.16);
      gain.gain.exponentialRampToValueAtTime(0.12, now + idx * 0.16 + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.16 + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + idx * 0.16);
      osc.stop(now + idx * 0.16 + 0.3);
    });
  } catch {
    // Ignore audio context restrictions cleanly
  }
}

function formatClock(totalSeconds) {
  const safe = Math.max(0, Math.ceil(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function initTimer() {
  const digitsEl = document.getElementById('timer-digits');
  const modeLabelEl = document.getElementById('timer-mode-label');
  const ringEl = document.getElementById('timer-ring-progress');
  const statusEl = document.getElementById('timer-status');

  const startBtn = document.getElementById('timer-start');
  const pauseBtn = document.getElementById('timer-pause');
  const resetBtn = document.getElementById('timer-reset');
  const soundToggleBtn = document.getElementById('timer-sound-toggle');

  const modeFocusBtn = document.getElementById('mode-focus');
  const modeBreakBtn = document.getElementById('mode-break');

  const settingsForm = document.getElementById('timer-settings-form');
  const focusInput = document.getElementById('focus-minutes');
  const breakInput = document.getElementById('break-minutes');
  const settingsMsg = document.getElementById('timer-settings-message');

  const metricSessions = document.getElementById('metric-sessions');
  const metricMinutes = document.getElementById('metric-minutes');
  const presetButtons = Array.from(document.querySelectorAll('[data-preset-focus]'));

  if (!digitsEl || !startBtn) return;

  const saved = { ...DEFAULT_STATE, ...loadData(STORAGE_KEYS.TIMER_STATE, DEFAULT_STATE) };
  const baseTitle = document.title;

  let mode = 'focus'; // 'focus' | 'break'
  let isRunning = false;
  let totalDurationMs = saved.focusMinutes * 60 * 1000;
  let remainingMs = totalDurationMs;
  let endTimestamp = null;
  let intervalId = null;

  const radius = 122;
  const circumference = 2 * Math.PI * radius;
  if (ringEl) {
    ringEl.style.strokeDasharray = `${circumference}`;
    ringEl.style.strokeDashoffset = '0';
  }

  focusInput.value = String(saved.focusMinutes);
  breakInput.value = String(saved.breakMinutes);

  function persistState() {
    saveData(STORAGE_KEYS.TIMER_STATE, saved);
  }

  function updateSoundButton() {
    if (!soundToggleBtn) return;
    soundToggleBtn.textContent = saved.soundEnabled ? 'Sound: On' : 'Sound: Off';
    soundToggleBtn.setAttribute('aria-pressed', String(saved.soundEnabled));
  }

  function setStatus(text, type = 'success') {
    if (!statusEl) return;
    if (!text) {
      statusEl.textContent = '';
      statusEl.className = 'form-message';
      return;
    }
    statusEl.textContent = text;
    statusEl.className = `form-message is-visible form-message--${type}`;
  }

  function setSettingsMsg(text, type = 'error') {
    if (!settingsMsg) return;
    if (!text) {
      settingsMsg.textContent = '';
      settingsMsg.className = 'form-message';
      return;
    }
    settingsMsg.textContent = text;
    settingsMsg.className = `form-message is-visible form-message--${type}`;
  }

  function render() {
    const secondsLeft = Math.max(0, Math.ceil(remainingMs / 1000));
    const clockStr = formatClock(secondsLeft);
    digitsEl.textContent = clockStr;
    modeLabelEl.textContent = mode === 'focus' ? 'Focus Session' : 'Break Interval';

    if (ringEl && totalDurationMs > 0) {
      const ratio = Math.max(0, Math.min(1, remainingMs / totalDurationMs));
      const offset = circumference * (1 - ratio);
      ringEl.style.strokeDashoffset = `${offset}`;
    }

    modeFocusBtn.classList.toggle('is-active', mode === 'focus');
    modeFocusBtn.setAttribute('aria-pressed', String(mode === 'focus'));
    modeBreakBtn.classList.toggle('is-active', mode === 'break');
    modeBreakBtn.setAttribute('aria-pressed', String(mode === 'break'));

    startBtn.disabled = isRunning;
    pauseBtn.disabled = !isRunning;

    metricSessions.textContent = String(saved.completedSessions);
    metricMinutes.textContent = `${saved.totalFocusMinutes}m`;

    document.title = isRunning
      ? `${clockStr} · ${mode === 'focus' ? 'Focus' : 'Break'} — KRUX STUDY`
      : baseTitle;
  }

  function stopInterval() {
    if (intervalId !== null) {
      window.clearInterval(intervalId);
      intervalId = null;
    }
  }

  function completeCycle() {
    stopInterval();
    isRunning = false;
    endTimestamp = null;
    remainingMs = 0;

    if (saved.soundEnabled) {
      playCompletionTone();
    }

    if (mode === 'focus') {
      saved.completedSessions += 1;
      saved.totalFocusMinutes += saved.focusMinutes;
      persistState();
      mode = 'break';
      totalDurationMs = saved.breakMinutes * 60 * 1000;
      remainingMs = totalDurationMs;
      setStatus(
        `Focus session complete. Ready for a ${saved.breakMinutes}-minute break.`,
        'success'
      );
    } else {
      mode = 'focus';
      totalDurationMs = saved.focusMinutes * 60 * 1000;
      remainingMs = totalDurationMs;
      setStatus(
        `Break complete. Ready for your next ${saved.focusMinutes}-minute focus session.`,
        'success'
      );
    }

    render();
  }

  function syncRemaining() {
    if (!isRunning || endTimestamp === null) return;
    const diff = endTimestamp - Date.now();
    if (diff <= 0) {
      completeCycle();
    } else {
      remainingMs = diff;
      render();
    }
  }

  function startTimer() {
    if (isRunning) return;
    if (remainingMs <= 0) {
      totalDurationMs = (mode === 'focus' ? saved.focusMinutes : saved.breakMinutes) * 60 * 1000;
      remainingMs = totalDurationMs;
    }
    setStatus('');
    isRunning = true;
    endTimestamp = Date.now() + remainingMs;
    stopInterval();
    intervalId = window.setInterval(syncRemaining, 250);
    render();
  }

  function pauseTimer() {
    if (!isRunning) return;
    syncRemaining();
    stopInterval();
    isRunning = false;
    endTimestamp = null;
    render();
  }

  function resetTimer() {
    stopInterval();
    isRunning = false;
    endTimestamp = null;
    totalDurationMs = (mode === 'focus' ? saved.focusMinutes : saved.breakMinutes) * 60 * 1000;
    remainingMs = totalDurationMs;
    setStatus('');
    render();
  }

  function switchMode(nextMode) {
    if (mode === nextMode && !isRunning) return;
    stopInterval();
    isRunning = false;
    endTimestamp = null;
    mode = nextMode;
    totalDurationMs = (mode === 'focus' ? saved.focusMinutes : saved.breakMinutes) * 60 * 1000;
    remainingMs = totalDurationMs;
    setStatus('');
    render();
  }

  startBtn.addEventListener('click', startTimer);
  pauseBtn.addEventListener('click', pauseTimer);
  resetBtn.addEventListener('click', resetTimer);

  modeFocusBtn.addEventListener('click', () => switchMode('focus'));
  modeBreakBtn.addEventListener('click', () => switchMode('break'));

  if (soundToggleBtn) {
    soundToggleBtn.addEventListener('click', () => {
      saved.soundEnabled = !saved.soundEnabled;
      persistState();
      updateSoundButton();
    });
  }

  settingsForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const fVal = Number(focusInput.value);
    const bVal = Number(breakInput.value);

    if (!Number.isFinite(fVal) || !Number.isInteger(fVal) || fVal < 1 || fVal > 180) {
      setSettingsMsg('Focus duration must be a whole number between 1 and 180 minutes.', 'error');
      focusInput.focus();
      return;
    }

    if (!Number.isFinite(bVal) || !Number.isInteger(bVal) || bVal < 1 || bVal > 60) {
      setSettingsMsg('Break duration must be a whole number between 1 and 60 minutes.', 'error');
      breakInput.focus();
      return;
    }

    saved.focusMinutes = fVal;
    saved.breakMinutes = bVal;
    persistState();
    setSettingsMsg(`Timer updated to ${fVal}m focus / ${bVal}m break.`, 'success');
    resetTimer();
  });

  presetButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      const fVal = Number(btn.getAttribute('data-preset-focus'));
      const bVal = Number(btn.getAttribute('data-preset-break'));
      if (!Number.isFinite(fVal) || !Number.isFinite(bVal)) return;

      saved.focusMinutes = fVal;
      saved.breakMinutes = bVal;
      focusInput.value = String(fVal);
      breakInput.value = String(bVal);
      persistState();
      setSettingsMsg(`Applied ${fVal}m focus / ${bVal}m break preset.`, 'success');
      resetTimer();
    });
  });

  // Handle background tab throttling accurately
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && isRunning) {
      syncRemaining();
    }
  });

  updateSoundButton();
  render();
}

document.addEventListener('DOMContentLoaded', initTimer);
